<?php
namespace app\index\controller;
use think\Db;
use think\Controller;
use think\Request;

header("Content-type: text/html; charset=utf-8");
header("Access-Control-Allow-Origin:*");

class Index extends Controller{


    public function index(){

		

       	if (Request::instance()->isPost()){

			$randMun=input('post.mun');

			$rs=Db::table('url')->where('url_name',$randMun)->find();
			
			if($rs){
				

				$rsmun=Db::table('mun')->where('weixin_mun',$rs['url_pid'])->where('stie','1')->where('pid','1')->select();

				$allmun =count($rsmun);

				if($allmun == 0 ){
					
					$datepid=['pid'=>'1'];
					Db::table('mun')->where('weixin_mun',$rs['url_pid'])->where('stie','1')->update($datepid);
				
				}

	
				$rsa=Db::table('mun')->where('weixin_mun',$rs['url_pid'])->where('stie','1')->where('pid','1')->order('list_id asc')->find();
					
				$mun=$rsa['list_mun']+1;
				$date=['list_mun'=>$mun,'pid'=>'0'];
				Db::table('mun')->where('list_id',$rsa['list_id'])->update($date);
		
				

				//echo $rsa['list_wx'];
				echo json_encode($rsa);die;


			}
	   
	   }else{
		
			echo '<br/>';die;
	   
	   }


    }






}
