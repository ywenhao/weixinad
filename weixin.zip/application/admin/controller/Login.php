<?php
namespace app\admin\controller;
use think\Controller;
use think\session;
use think\Db;

header("Content-type: text/html; charset=utf-8");

class Login extends controller{



    public function index(){

		return view();

    }






}
