<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;

class User extends Base{


    public function index(){

		$id=session('useid');
		
		$rs=Db::table('user')->where('useid',$id)->find();

		$this->assign('user',$rs);

        return view();

    }



 	public function updateadmin(){

		$name=input('post.name');
		$pw=input('post.pw');
		$pwa=input('post.pwa');
		
	

		if($name==null){
		
			echo '1';die;
		
		}else if($pw==null){
		
			echo '2';die;
		
		}else if($pwa==null){
		
			echo '3';die;
		
		}else if($pwa!=$pw){
		
			echo '4';die;

		}else{	

			$find=Db::table('user')->where('useid','1')->find();
			
			if($name==$find['usename'] && $pw==$find['usepassword']){
			
				echo '6';die;
			
			}
		
			$date=['usename'=>$name,'usepassword'=>$pw,];

			$rs=Db::table('user')->where('useid','1')->update($date);

			if($rs){
				
				echo '5';die;
			
			}
				

		}
	}



}
