<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
use think\session;
header("Content-type: text/html; charset=utf-8");
class Base extends Controller{



    public function _initialize(){


		if (!isset($_SERVER['HTTP_REFERER'])) {
         
           $this->redirect('/404.html');
          
        }


      }







}
