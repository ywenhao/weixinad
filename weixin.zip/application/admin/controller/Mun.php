<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;

class Mun extends  Base{


    public function index(){
		
		$id=input('get.id');

		$rs=Db::table('mun')->alias('a')->join('pid b','b.pid_id= a.stie')->where('weixin_mun',$id)->paginate('5',false,['query' => ['id'=>$id],]);

		$url=Db::table('url')->where('url_pid',$id)->order('url_id desc')->select();

		$rsname=Db::table('weixin')->where('weixin_id',$id)->find();

		$this->assign('munurl',$url);
		$this->assign('id',$id);
		$this->assign('list',$rs);
		$this->assign('name',$rsname['weixin_name']);

		return view();
		
    }


    public function insert(){

		$id=input('post.id');	
		$name=input('post.name');
		$wxmun=input('post.mun');
		$file = request()->file('img');
		

		if($name == NULL){
			
			echo '1';die;
		
		}else if($wxmun == NULL){
			
			echo '2';die;
		
		}else if($file == NULL){
			
			echo '3';die;

		}else{

			
			if($file){
				$info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
				if($info){

					$img=str_replace("\\","/",$info->getSaveName());
				 // $img=$info->getSaveName();
				}
			}
			
			$date=['list_name'=>$name,'list_wx'=>$wxmun,'list_img'=>$img,'weixin_mun'=>$id];

			$rs=Db::table('mun')->insert($date);
			
			if($rs){
				
				echo '4';die;
			
			}

		}
			
    }

    public function updatemun(){

		$id=input('post.id');	
		$name=input('post.name');
		$wxmun=input('post.mun');
		$file = request()->file('img');


		if($name == NULL){

			echo '1';die;

		}else if($wxmun == NULL){
			
			echo '2';die;
		
		}else if($file == NULL){
			
			$date=['list_name'=>$name,'list_wx'=>$wxmun];

		}else if($file != NULL){

			if($file){
				$info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
				if($info){
					$img=str_replace("\\","/",$info->getSaveName());
				}
			}
			$date=['list_name'=>$name,'list_wx'=>$wxmun,'list_img'=>$img];
		}	

			$rs=Db::table('mun')->where('list_id',$id)->update($date);
			
			if($rs){
				
				echo '3';die;
			
			}

			
    }



    public function delone(){
		
		$id=input('post.a');
		$rs=Db::table('mun')->where('list_id',$id)->delete();
		if($rs){
			echo '1';die;
		}
		
    }

    public function delall(){
		
		$id=input('post.ids');
		$rs=Db::table('mun')->where('list_id')->delete($id);
		if($rs){
			echo '1';die;
		}	

    }

    public function munover(){
		
		$id=input('post.a');
		$date=['list_mun'=>'0'];
		$rs=Db::table('mun')->where('list_id',$id)->update($date);
		if($rs){
			echo '1';die;
		}	

    }



	public function site(){

		$id=input('post.a');
		$pid=input('post.b');
		if($pid ==1 ){
			
			$date=['a.stie'=>0];

		}else{
		
			$date=['a.stie'=>1];
		}


		
		$rs=Db::table('mun')->alias('a')->join('pid b','b.pid_id= a.stie')->where('a.list_id',$id)->update($date);

		if($rs){
			echo '1';die;
		}
	
	}




}
