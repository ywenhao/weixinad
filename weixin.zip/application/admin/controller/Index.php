<?php
namespace app\admin\controller;
use think\Controller;
use think\session;
use think\Db;

header("Content-type: text/html; charset=utf-8");

class Index extends Base{

    public function index(){
		
		$id=session('useid');
		if($id==NULL){
			$this->redirect('/login');
		}else{
			return view();
		}
    }



    public function comlogin(){
			
		
		$name=input('post.name');
		$pw=input('post.pw');
		$add=input('post.add');
		$code=input('post.yzm');

	

		if($name==NULL){
		
			echo '1';die;
		
		}else if($pw==NULL){
		
			echo '2';die;

		}else if($code==NULL){
		
			echo '7';die;

		}else if(!captcha_check($code)){
		
			echo '6';die;

		}else{

			$rs=Db::table('user')->where('usename',$name)->find();

			if($rs){
				
				if($rs['usepassword']==$pw){
					
						session('useid',$rs['useid']);
						$date=['usetime'=>date("Y-m-d H:i:s"),'useadd'=>$add];
						Db::table('user')->where('useid',$rs['useid'])->update($date);
						echo '4';die;
				
				}else{
				
					echo '5';die;
				
				}
			
			}else{
			
				echo '3';die;
			
			
			}
		
		
		
		}

    }






    public function out(){

		session('useid',NULL);
		
		echo '1';

    }




    public function top(){

		$id=session('useid');
		$rs=Db::table('user')->where('useid',$id)->find();
		$this->assign('use',$rs);
		return view();
    }



    public function nav(){


         return view();

    }


    public function mian(){

        $id=session('useid');
		$rs=Db::table('user')->where('useid',$id)->find();
		$weixin=Db::table('weixin')->select();
		$mun=count($weixin);
		$this->assign('user',$rs);
		$this->assign('mun',$mun);
		return view();

    }



}
