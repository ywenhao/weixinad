<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;

class Weixin extends Base{


    public function index(){

		$id='8';
		$rs=Db::table('weixin')->alias('a')->join('pid b ','a.weixin_stie= b.pid_id')->paginate(5);
		$this->assign('list',$rs);
		return view();
		
    }

    public function search(){

		$name=input('post.search');
		$rs=Db::table('url')->alias('a')->join('weixin b ','a.url_pid= b.weixin_id')->join('pid c','b.weixin_stie = c.pid_id')->where('a.url_name','like',$name)->paginate(5);
		$this->assign('list',$rs);
		return view();
		
    }



    public function insert(){

		$name=input('post.inname');

		
		if($name == NULL){
		
			echo '1';die;
		
		}else{
		
			$mun=rand(100000000, 999999999);
			$date=['weixin_name'=>$name,'weixin_time'=>date('Y-m-d H:i:s'),'weixin_rand'=>$mun];
			$row=Db::table('weixin')->insert($date);

			if($row){
				
				echo '2';die;
			
			}	
		}	
    }

	 public function delone(){

		$id=input('post.a');
		$row=Db::table('weixin')->where('weixin_id',$id)->delete();
		Db::table('url')->where('url_pid',$id)->delete();
		Db::table('mun')->where('weixin_mun',$id)->delete();
		
		echo '1';die;
			
	}


	 public function delall(){

		$id=input('post.ids');
		$row=Db::table('weixin')->delete($id);
		if($row){
			echo '1';die;
		}	
	}

	 public function stie(){

		$id=input('post.a');
		$stie=input('post.b');
		if($stie == 0){

			$date=['weixin_stie'=>'1'];
			$row=Db::table('weixin')->where('weixin_id',$id)->update($date);
			if($row){
				echo '1';die;
			}

		}else if($stie == 1){
		
			$date=['weixin_stie'=>'0'];
			$row=Db::table('weixin')->where('weixin_id',$id)->update($date);
			if($row){
				echo '2';die;
			}
		
		}
		
	
	}


	public function update(){
	
		$id=input('post.id');
		$xiu=input('post.xiu');
			
		if($xiu==NULL){
			
			echo '1';die;
		
		}else{

			$row=Db::table('weixin')->where('weixin_name',$xiu)->find();
			if($row){	
				echo '2';die;
			}

			$date=['weixin_name'=>$xiu];
			$rs=Db::table('weixin')->where('weixin_id',$id)->update($date);

			if($rs){
				
				echo '3';die;
			
			}

		
		}


	
	}




}
