<?php
namespace app\admin\controller;
use think\Controller;
use think\Db;

class Url extends  Base{


    public function inserturl(){

		$id=input('post.a');
		$name=input('post.urlmun');

		if($name==NULL){

			echo '1';die;

		}else{
				$urlmun=Db::table('url')->alias('a')->join('weixin b','b.weixin_id= a.url_pid')->where('a.url_name',$name)->find();

				if($urlmun){
				
					echo '3';die;
				
				}else{
				
					$date=['url_name'=>$name,'url_pid'=>$id];
					$rs=Db::table('url')->insert($date);
					if($rs){
						echo '2';die;
					}	
			
				}
			}


		}

    

		  public function delurl(){
			$id=input('post.a');
			$rs=Db::table('url')->where('url_id',$id)->delete();
			if($rs){
				echo '1';die;
			}
		  }



}
