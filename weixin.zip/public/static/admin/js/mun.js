			function inserturlmun(a){
				var urlmun=$('#aurl').val();
					$.ajax({
					type:"POST",
					url:"../url/inserturl",
					data:{urlmun:urlmun,a:a},
						success:function(c){
							if(c==1){
								show('URL不能为空');
							}else if(c==2){
								show('添加成功');	
							}else if(c==3){
								show('检查其他列表 域名已经存在');	
							}
						}			
					})
			}

			function inserturl(){
		
				$('.row3b').fadeToggle();		
			}




			function show(a){
				$('#showText').html(a);
				$('#showText').fadeIn();
				setTimeout(function(){ 
					$('#showText').fadeOut();
					if(a=='删除成功' ||a=='状态修改成功'||a=='创建成功'||a=='修改成功'||a=='添加成功' ||a=='清理成功'){
						history.go(0);
					}
				}, 2000);	
			}	

			function go(){
				history.go(0);
			}
			function back(){
				history.go(-1);
			}
		

		
	function ok(){
		var form = document.getElementById('updateform');
		var formData = new FormData(form);
		$.ajax({
			type:"POST",
			url:"insert",
			data:formData,
            contentType: false, // 注意这里应设为false
            processData: false,
            cache: false,
			success:function(a){
			
					if(a==1){
							
						show('客服不能为空');

					}else if(a==2){

						show('微信不能为空');
					
					}else if(a==3){
					
						show('二维码不能空');			

					}else if(a==4){
					
						show('添加成功');
					
					}
			
			}
		})
	}

	function updatemun(){
		var form = document.getElementById('updateforma');
		var formData = new FormData(form);
		$.ajax({
			type:"POST",
			url:"updatemun",
			data:formData,
            contentType: false, // 注意这里应设为false
            processData: false,
            cache: false,
			success:function(a){
			
					if(a==1){
							
						show('客服不能为空');

					}else if(a==2){

						show('微信不能为空');
					
					}else if(a==3){
					
						show('修改成功');
					
					}
			
			}
		})
	}


		$(document).on('click','#checkAll',function() {
			var flag = $("#checkAll").is(':checked');
			$("input[name='chk_item']:checkbox").each(function() {
		        $(this).prop("checked", flag);
			});
		});
		


		function alldel(){

			var ids = "";

			$("input[name='chk_item']:checkbox").each(function() {
					var flag = $(this).is(':checked');

					if(flag){

						ids += $(this).val() + ",";
					
					}
			});

			if(ids == ""){
			
				show('请选中要删除的编号');
			
			}else{
			$.ajax({
					type:"POST",
					url:"delall",
					data:{ids:ids},
					success:function(v){
						if(v==1){
						
							show('删除成功');
						}
					}
				})
				
			}
		}

			function godel(a){
				$.ajax({
					type:"POST",
					url:"delone",
					data:{a:a},
					success:function(c){
						if(c==1){
							show('删除成功');					
						}
					}
				})
			}


			function insertrow(){
				$('.row3').fadeToggle();		
			}


			function xiugai(a,b,c,d){
				if(a!=null){	
					$('#xiu_name').val(b);
					$('#xiu_mun').val(c);
					var e='/uploads/'+d;
					$('#xiu_img').attr('src',e);
					$('#xiu_id').val(a);
				}
				$('.row3a').fadeToggle();		
			}
			function showtext(a){
				$('#show').html(a);
				$('.row3').fadeToggle();		
			}
			function insert(){
				
				var inname=$('#inname').val();
				var inpw=$('#inpw').val();
			
					$.ajax({
				
					type:"POST",
					url:"insert",
					data:{inname:inname,inpw:inpw},

						success:function(c){

							if(c==1){
							
								show('名称不能为空');

							}else if(c==2){

								show('域名列表不能为空');
							
							}else if(c==3){
							
								show('创建成功');			

							}

						}
				
				
					})
				
				


			}

			function urldel(a){
				$.ajax({
				type:"POST",
				url:"../url/delurl",
				data:{a:a},
					success:function(c){
						if(c==1){
							show('删除成功');
						}
					}
				})	
			
			
			}
			function site(a,b){
				$.ajax({
				type:"POST",
				url:"site",
				data:{a:a,b:b},
					success:function(c){
						if(c==1){
						
							show('修改成功');
						}
					}
				})	
			}

			function munover(a,b){
				if(b==0){
					show('已经是0了不用清理了');
				}else{
				$.ajax({
				type:"POST",
				url:"munover",
				data:{a:a},
					success:function(c){
						if(c==1){
						
							show('清理成功');
						}
					}
				})	
			}}