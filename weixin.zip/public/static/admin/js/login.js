	function show(a){
		$('#showText').html(a);
		$('#showText').fadeIn();
		setTimeout(function(){ 
			$('#showText').fadeOut();
			if(a=='登录成功' ){
			
				window.location="/index";
			}else if(a=='验证码不正确'){
			
				refreshVerify();
			}
		}, 2000);	
	}

	
    function refreshVerify() {
		
       var ts = Date.parse(new Date())/1000;
	   var url=$('.yzm img').attr('src');
        $('.yzm img').attr("src", url+'?'+ts);

		
    }



	function login(){
		
		var name=$('#firstname').val();
		var pw=$('#lastname').val();
		var yzm=$('#yzm').val();	
		var add =localAddress.province+"-"+localAddress.city;


			$.ajax({
		
			type:"POST",
			url:"http://ribenkanbing.cn/comlogin",
			data:{name:name,pw:pw,yzm:yzm,add:add},

				success:function(a){

					
					if(a==1){
					
						show('账户不能为空');
					
					}else if(a==2){
					
						show('密码不能为空');

					}else if(a==3){

						show('账户名不对');
					
					}else if(a==4){
					
						show('登录成功');			

					}else if(a==5){
					
						show('密码错误');

					}else if(a==7){
					
						show('请输入验证码');

					}else if(a==6){
					
						show('验证码不正确');
						
					}
					
				}
		
		
			})
		
		


	}