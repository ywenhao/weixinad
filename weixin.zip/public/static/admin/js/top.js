	function show(a){
	
		$('#showText').html(a);
		$('#showText').fadeIn();

		setTimeout(function(){ 
		
			$('#showText').fadeOut();
		
		}, 2500);
	
	}


	function out(){
	
		var out = confirm('确认退出？');

		if(out){
			
			$.ajax({
		
				type:"POST",
				url:"out",

				success:function(a){


					if(a==1){

						show('退出成功');
						top.location.reload();

					}
				
				}
		
		
			})
		
		
		}
	
	}