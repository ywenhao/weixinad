<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\phpStudy\PHPTutorial\WWW\weixin\public/../application/admin\view\index\mian.html";i:1549677845;}*/ ?>
<!doctype html>
	<head>
		<meta charset="UTF-8">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
		<!--强制让文档的宽度与设备的宽度保持1:1，并且文档最大的宽度比例是1.0，且不允许用户点击屏幕放大浏览；--> 
		<meta content="yes" name="apple-mobile-web-app-capable" /> 
		<!--iphone设备中的safari私有meta标签，它表示：允许全屏模式浏览--> 
		<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 
		<!--iphone的私有标签，它指定的iphone中safari顶端的状态条的样式--> 
		<meta name="format-detection" content="telephone=no" /> 
		<!--忽略将页面中的数字识别为电话号码--> 
		<meta name="format-detection" content="email=no" /> 
		<!--忽略Android平台中对邮箱地址的识别 --> 
		<meta name="viewport" content="width=320, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;">
		<title></title> 
		<link rel="stylesheet" href="/weixin/public/static/admin/css/style.css" />
	</head>
	<body>
		<div class="mian">
			
			
		
			<div class="back"><i class="iconfont">&#xe758;</i>欢迎登录后台管理</div>

			<div class="row5">
				<ul>

					<li>
						<p><i class="iconfont">&#xe630;</i>账户名</p>
						<p><a href="<?php echo url('user/index'); ?>"><?php echo $user['usename']; ?></a></p>					
					</li>

					<li>
						<p><i class="iconfont">&#xe745;</i>登录时间</p>
						<p><a href="<?php echo url('user/index'); ?>"><?php echo $user['usetime']; ?></a></p>					
					</li>

					<li>
						<p><i class="iconfont">&#xe76c;</i>栏目单元</p>
						<p><a href="<?php echo url('weixin/index'); ?>"><?php echo $mun; ?> 个</a></p>					
					</li>

				

				</ul>
			</div>






		</div>


		</div>
	</body>
</html>
