<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpStudy\PHPTutorial\WWW\weixin\public/../application/admin\view\weixin\search.html";i:1549677844;}*/ ?>
<!doctype html>
	<head>
		<meta charset="UTF-8">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
		<!--强制让文档的宽度与设备的宽度保持1:1，并且文档最大的宽度比例是1.0，且不允许用户点击屏幕放大浏览；--> 
		<meta content="yes" name="apple-mobile-web-app-capable" /> 
		<!--iphone设备中的safari私有meta标签，它表示：允许全屏模式浏览--> 
		<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 
		<!--iphone的私有标签，它指定的iphone中safari顶端的状态条的样式--> 
		<meta name="format-detection" content="telephone=no" /> 
		<!--忽略将页面中的数字识别为电话号码--> 
		<meta name="format-detection" content="email=no" /> 
		<!--忽略Android平台中对邮箱地址的识别 --> 
		<title></title> 
		<link rel="stylesheet" href="/weixin/public/static/admin/css/style.css" />
		<script src="/weixin/public/static/admin/js/jquery.js" ></script>
	</head>
	<body>
		<div class="mian">
			<div id="showText" style="display:none"></div>
			<div id="user">
	
				<div class="back">
				
				<i class="iconfont">&#xe632;</i>搜索结果
	

				<button onclick="back()"><i class="iconfont">&#xe624;</i>返回上一页</button>
				</div>
				<div class="listuse">
					<table class="namelist" >
						<tr>
							<td><input onclick="checkall()"  type="checkbox" id="checkAll" value="全选"></td>
							<td>单元名称</td>
							<td>查看列表微信</td>
							<!-- <td>列表值</td> -->
							<td>创建时间</td>
							<td><i class="iconfont">&#xe753;</i>操作</td>
						</tr>

						<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<tr>
							<td><input name="chk_item" type="checkbox" value="<?php echo $vo['weixin_id']; ?>"></td>
							<td><?php echo $vo['weixin_name']; ?></td>
						
							<td><a href="<?php echo url('mun/index'); ?>?id=<?php echo $vo['weixin_id']; ?>">点击查看</a></td>
							<!-- <td><?php echo $vo['weixin_rand']; ?></td> -->
							<td><?php echo $vo['weixin_time']; ?></td>
							<td>
								<!-- <a href="javascript:shenhe()"><i class="iconfont">&#xe757;</i></a> -->
								<a href="javascript:stie(<?php echo $vo['weixin_id']; ?>,<?php echo $vo['weixin_stie']; ?>)"><i class="iconfont" ><?php echo $vo['pid_img']; ?></i></a> 
								<a href="javascript:godel(<?php echo $vo['weixin_id']; ?>)" ><i class="iconfont">&#xe759;</i></a>
							</td>
						</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>

					</table>
				</div>
					<?php echo $list->render(); ?>
			</div>

		</div>




		<script>


			function show(a){
				$('#showText').html(a);
				$('#showText').fadeIn();
				setTimeout(function(){ 
					$('#showText').fadeOut();
					if(a=='删除成功' ||a=='开启成功'||a=='暂停成功'||a=='创建成功'||a=='修改成功'||a=='添加成功'){
						history.go(0);
					}
				}, 2000);	
			}	

			function go(){
				history.go(0);
			}

		

		

		</script>


		<script>	



			function godel(a){
				$.ajax({
					type:"POST",
					url:"delone",
					data:{a:a},
					success:function(c){
						if(c==1){
							show('删除成功');					
						}
					}
				})
			}

			function back(){
				history.go(-1);
			}
			function stie(a,b){
				$.ajax({
					type:"POST",
					url:"stie",
					data:{a:a,b:b},
						success:function(c){
							if(c==1){
							
								show('开启成功');

							}else if(c==2){

								show('暂停成功');
							
							}

						}	
				
					})
			
			}

 </script>



	</body>
</html>
