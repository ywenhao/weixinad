<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\phpStudy\PHPTutorial\WWW\weixin\public/../application/admin\view\mun\index.html";i:1549681664;}*/ ?>
<!doctype html>
	<head>
		<meta charset="UTF-8">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
		<!--强制让文档的宽度与设备的宽度保持1:1，并且文档最大的宽度比例是1.0，且不允许用户点击屏幕放大浏览；--> 
		<meta content="yes" name="apple-mobile-web-app-capable" /> 
		<!--iphone设备中的safari私有meta标签，它表示：允许全屏模式浏览--> 
		<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 
		<!--iphone的私有标签，它指定的iphone中safari顶端的状态条的样式--> 
		<meta name="format-detection" content="telephone=no" /> 
		<!--忽略将页面中的数字识别为电话号码--> 
		<meta name="format-detection" content="email=no" /> 
		<!--忽略Android平台中对邮箱地址的识别 --> 
		<title></title> 
		<link rel="stylesheet" href="/weixin/public/static/admin/css/style.css" />
		<script src="/weixin/public/static/admin/js/jquery.js" ></script>
	</head>
	<body>
		<div class="mian">
			<div id="showText" style="display:none"></div>
			<div id="user">
	
				<div class="back">
				
				<i class="iconfont">&#xe749;</i>单元栏目: <?php echo $name; ?>


				<button onclick="alldel()"><i class="iconfont">&#xe759;</i>批量删除</button>
				<button onclick="go()"><i class="iconfont">&#xe653;</i>刷新本页</button>
				<button onclick="insertrow()"><i class="iconfont">&#xe76c;</i>添加微信</button>
				<button onclick="inserturl()"><i class="iconfont">&#xe76c;</i>添加域名</button>
				<button onclick="back()"><i class="iconfont">&#xe624;</i>返回上一页</button>
				</div>

				

				<div class="url">
					
						<ul>

						<?php if(is_array($munurl) || $munurl instanceof \think\Collection || $munurl instanceof \think\Paginator): $i = 0; $__LIST__ = $munurl;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vov): $mod = ($i % 2 );++$i;?>
							<li>  
								<b><?php echo $vov['url_name']; ?></b>
								<span>				
										
									<a href="<?php echo $vov['url_name']; ?>" target="_blank" ><i class="iconfont">&#xe75f;</i></a>
									<a href="javascript:urldel(<?php echo $vov['url_id']; ?>)" ><i class="iconfont">&#xe759;</i></a>	
								</span>							
							</li>
						<?php endforeach; endif; else: echo "" ;endif; ?>


						<ul>
				</div>

				<div class="listuse">
					<table class="namelist" >
						<tr>
							<td><input onclick="checkall()"  type="checkbox" id="checkAll" value="全选"></td>
							<td>客服</td>
							<td>微信</td>
							<td>二维码</td>
							<td>展示次数</td>
							<td>状态</td>
							<td><i class="iconfont">&#xe753;</i>操作</td>
						</tr>

						<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<tr id="<?php echo $vo['list_id']; ?>">
							<td><input name="chk_item" type="checkbox" value="<?php echo $vo['list_id']; ?>"></td>
							<td><?php echo $vo['list_name']; ?></td>
							<td><?php echo $vo['list_wx']; ?></td>
							<td><img src="/weixin/public/uploads/<?php echo $vo['list_img']; ?>"  width="40" height="40"/></td>
							<td><?php echo $vo['list_mun']; ?><span  class="cursor munover" onclick="munover(<?php echo $vo['list_id']; ?>,<?php echo $vo['list_mun']; ?>)">清零</span></td>
							<td  class="cursor" onclick="site(<?php echo $vo['list_id']; ?>,<?php echo $vo['pid_id']; ?>)"><i class="iconfont" alt="修改"><?php echo $vo['pid_img']; ?></i><?php echo $vo['pid_text']; ?></td>
							<td>
								<a href="javascript:xiugai(<?php echo $vo['list_id']; ?>,'<?php echo $vo['list_name']; ?>','<?php echo $vo['list_wx']; ?>','<?php echo $vo['list_img']; ?>')"><i class="iconfont" alt="修改">&#xe757;</i></a>
								<a href="javascript:godel(<?php echo $vo['list_id']; ?>)" ><i class="iconfont" alt="删除">&#xe759;</i></a>
							</td>
						</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>

					</table>
				</div>
					<?php echo $list->render(); ?>
			</div>

		</div>




		<div class="row3" style="display:none">
			<div class="row3_mian">
				<form role="form" id="updateform"  onsubmit="return false" enctype="multipart/form-data">
					<P><span>客服名称</span><input type="text" name="name"  autocomplete="off" value="" placeholder='请输入'/></p>
					<P><span>微信号码</span><input type="text" value="" autocomplete="off" name="mun"  placeholder='请输入'/></p>
					<P><span>微信图片</span><input type="file" id="inputfile" style="padding:0px;" name="img"></p>
					<P></p>
					<input type="hidden" value="<?php echo $id; ?>" name="id" />
				</form>
				<div id="button">
				<button type="submit" onclick="ok()">提交</button>
				<button class="hide"></button>
				<button onclick="insertrow()">关闭</button>	
				</div>
			</div>
		</div>


		<div class="row3a" style="display:none">
			<div class="row3_mian">
				<form role="form" id="updateforma"  onsubmit="return false" enctype="multipart/form-data">
					<P><span>客服名称</span><input id="xiu_name" type="text" name="name"  autocomplete="off" value="" placeholder='请输入'/></p>
					<P><span>微信号码</span><input id="xiu_mun" type="text" value="" autocomplete="off" name="mun"  placeholder='请输入'/></p>
					<P><span>微信图片</span><input type="file" id="inputfile" style="padding:0px;" name="img"></p>
					<br/>
					<!-- <img src="" id="xiu_img" width="200px;height:200px;"/> -->
					<P></p>
					<input type="hidden" value="" id="xiu_id" name="id" />
				</form>
				<div id="button">
				<button type="submit" onclick="updatemun()">提交</button>
				<button class="hide"></button>
				<button onclick="xiugai()">关闭</button>	
				</div>
			</div>
		</div>

		<div class="row3b" style="display:none">
			<div class="row3_mian">
				<form role="form"   onsubmit="return false" >
					<P><span>域名url</span><input id="aurl"  type="text"  autocomplete="off" value="" placeholder='请输入'/></p>
				</form>
				<p style="font-size:12px;margin-top:20px;">注：请输入完整域名http:// 或者https://</p>
				<div id="button">
				<button type="submit" onclick="inserturlmun(<?php echo $id; ?>)">提交</button>
				<button class="hide"></button>
				<button onclick="inserturl()">关闭</button>	
				
				</div>
			</div>
		</div>




		<script src="/weixin/public/static/admin/js/mun.js"></script>



	</body>
</html>
