<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\phpStudy\PHPTutorial\WWW\weixin\public/../application/admin\view\user\index.html";i:1549677844;}*/ ?>
<!doctype html>
	<head>
		<meta charset="UTF-8">
		<meta name="Keywords" content="">
		<meta name="Description" content="">
		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 
		<!--强制让文档的宽度与设备的宽度保持1:1，并且文档最大的宽度比例是1.0，且不允许用户点击屏幕放大浏览；--> 
		<meta content="yes" name="apple-mobile-web-app-capable" /> 
		<!--iphone设备中的safari私有meta标签，它表示：允许全屏模式浏览--> 
		<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 
		<!--iphone的私有标签，它指定的iphone中safari顶端的状态条的样式--> 
		<meta name="format-detection" content="telephone=no" /> 
		<!--忽略将页面中的数字识别为电话号码--> 
		<meta name="format-detection" content="email=no" /> 
		<!--忽略Android平台中对邮箱地址的识别 --> 
		<meta name="viewport" content="width=320, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;">
		<title></title> 
		<link rel="stylesheet" href="/weixin/public/static/admin/css/style.css" />
		<script src="/weixin/public/static/admin/js/jquery.js"></script>
	</head>
	<body>
		<div class="mian">
			<div id="showText" style="display:none"></div>
			<div id="user">

			
				<div class="back">
					<i class="iconfont">&#xe627;</i>账户管理
				</div>


				<table class="name">
					<tr>
						<td><i class="iconfont">&#xe743;</i>用户名</td>
						<td><i class="iconfont">&#xe75f;</i>密码</td>
						<td><i class="iconfont">&#xe768;</i>登录地址</td>
						<td><i class="iconfont">&#xe745;</i>登录时间</td>
						<td><i class="iconfont">&#xe753;</i>操作</td>
					</tr>
					<tr>
						<td><?php echo $user['usename']; ?></td>
						<td><?php echo $user['usepassword']; ?></td>
						<td><?php echo $user['useadd']; ?></td>
						<td><?php echo $user['usetime']; ?></td>
						<td>

							<a href="javascript:;" onclick="update()"><i class="iconfont">&#xe757;</i>修改</a>  
						
						</td>
					</tr>
				</table>


			</div>

		</div>


		<div class="row3" style="display:none">
			<div class="row3_mian">
				<h3><i  class="iconfont">&#xe757;</i>密码修改</h3>

				<form method="post" onsubmit="return false">
					<P><span>账&nbsp;户&nbsp;名</span><input type="text" id="name"  autocomplete="off"   value="<?php echo $user['usename']; ?>"/></p>
					<P><span>密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码</span><input autocomplete="off" type="text" value="<?php echo $user['usepassword']; ?>" id='pw'  /></p>
					<P><span>确认密码</span><input type="text" value="" id='pwa' autocomplete="off"  placeholder='请输入'/></p>

					<div id="button">
						<button type="submit" onclick="updateuser()">修改</button>
						<button style="display:none"></button>
						<button onclick="update()">关闭</button>
					</div>

				</form>
			</div>
		</div>











		<script>
			
			function show(a){
				$('#showText').html(a);
				$('#showText').fadeIn();
				setTimeout(function(){ 
					$('#showText').fadeOut();
					if(a=='修改成功'){
						history.go(0);
					}

				}, 2000);
			}

			function update(){
				
				$('.row3').fadeToggle();
			
			}
	

		function updateuser(){
		
			var name=$('#name').val();
			var pw=$('#pw').val();
			var pwa=$('#pwa').val();
			

			
			$.ajax({
		
			type:"POST",
			url:"updateadmin",
			data:{name:name,pw:pw,pwa:pwa},

				success:function(a){

				
					
					if(a==1){
					
						show('账户不能为空');
					
					}else if(a==2){
					
						show('密码不能为空');

					}else if(a==3){

						show('请确认二次密码');
					
					}else if(a==4){
					
						show('密码不一致');			

					}else if(a==5){
					
						show('修改成功');

					}else if(a==6){
					
						show('账户密码和系统一致');
						

					}
				
				}	
		
			})
		}

		</script>
	</body>
</html>
