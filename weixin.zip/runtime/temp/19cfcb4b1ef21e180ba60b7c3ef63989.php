<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/www/wwwroot/ht.mx-lucky.com/public/../application/admin/view/index/index.html";i:1549677844;}*/ ?>
<!doctype html>



	<meta charset="UTF-8">

	<meta name="Keywords" content="">

	<meta name="Description" content="">

	  <title>后台管理</title>

<frameset rows="60px,*" cols="*" frameborder="yes" border="0" >



	<frame src="<?php echo url('index/top'); ?>"/></frame>



<frameset cols="180px,*" frameborder="yes" >



	<frame src="<?php echo url('index/nav'); ?>"></frame>

	<frame src="<?php echo url('index/mian'); ?>" name="goFrame" scrolling="yes"></frame>





</frameset>





</html>

