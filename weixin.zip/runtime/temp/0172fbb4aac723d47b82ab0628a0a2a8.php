<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"/www/wwwroot/ht.mx-lucky.com/public/../application/admin/view/weixin/index.html";i:1549862640;}*/ ?>
<!doctype html>

	<head>

		<meta charset="UTF-8">

		<meta name="Keywords" content="">

		<meta name="Description" content="">

		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" /> 

		<!--强制让文档的宽度与设备的宽度保持1:1，并且文档最大的宽度比例是1.0，且不允许用户点击屏幕放大浏览；--> 

		<meta content="yes" name="apple-mobile-web-app-capable" /> 

		<!--iphone设备中的safari私有meta标签，它表示：允许全屏模式浏览--> 

		<meta content="black" name="apple-mobile-web-app-status-bar-style" /> 

		<!--iphone的私有标签，它指定的iphone中safari顶端的状态条的样式--> 

		<meta name="format-detection" content="telephone=no" /> 

		<!--忽略将页面中的数字识别为电话号码--> 

		<meta name="format-detection" content="email=no" /> 

		<!--忽略Android平台中对邮箱地址的识别 --> 

		<title></title> 

		<link rel="stylesheet" href="/static/admin/css/style.css" />

		<script src="/static/admin/js/jquery.js" ></script>

	</head>

	<body>

		<div class="mian">

			<div id="showText" style="display:none"></div>

			<div id="user">

	

				<div class="back">

				

				<i class="iconfont">&#xe76c;</i>列表管理



				<div class="search" >

					<form  method="post" action="<?php echo url('search'); ?>"/>

					<select name="text" id="text">

					  <option value ="usename">域名查找</option>

		

					</select>

					<input type="text" id="sou" name="search" placeholder="请输入域名查询">

					<i class="iconfont">&#xe632;<input type="submit" id="submit" value="搜索"/></i>

					</form>

				</div>





				<!-- <button onclick="alldel()"><i class="iconfont">&#xe759;</i>批量删除</button> -->

				<button onclick="go()"><i class="iconfont">&#xe653;</i>刷新本页</button>

				<button onclick="insertrow()"><i class="iconfont">&#xe75b;</i>创建单元</button>





				</div>

				<div class="listuse">

					<table class="namelist" >

						<tr>

							<td><input onclick="checkall()"  type="checkbox" id="checkAll" value="全选"></td>

							<td>单元名称</td>

							<td>查看列表微信</td>


							<td>创建时间</td>

							<td><i class="iconfont">&#xe753;</i>操作</td>

						</tr>



						<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

						<tr>

							<td><input name="chk_item" type="checkbox" value="<?php echo $vo['weixin_id']; ?>"></td>

							<td><?php echo $vo['weixin_name']; ?></td>


							<td><a href="<?php echo url('mun/index'); ?>?id=<?php echo $vo['weixin_id']; ?>">点击查看</a></td>


							<td><?php echo $vo['weixin_time']; ?></td>

							<td>

								<a href="javascript:xiu('<?php echo $vo['weixin_name']; ?>',<?php echo $vo['weixin_id']; ?>)"><i class="iconfont">&#xe757;</i></a> 

								<!-- <a href="javascript:stie(<?php echo $vo['weixin_id']; ?>,<?php echo $vo['weixin_stie']; ?>)"><i class="iconfont" ><?php echo $vo['pid_img']; ?></i></a>  -->

								<a href="javascript:godel(<?php echo $vo['weixin_id']; ?>)" ><i class="iconfont">&#xe759;</i></a>

							</td>

						</tr>

					<?php endforeach; endif; else: echo "" ;endif; ?>



					</table>

				</div>

					<?php echo $list->render(); ?>

			</div>



		</div>





		<div class="row3" style="display:none">

			<div class="row3_mian">

				<h3><i  class="iconfont">&#xe757;</i>单元名称修改</h3>		

				<P><input type="text" id="xiu" style="display:block;width:100%" autocomplete="off"  value="" /></p>
				<input type="hidden" id="id" value=''/>
				<div id="button">
					<button type="submit" onclick="update()">修改</button>
					<button style="display:none"></button>
					<button onclick="xiu()">关闭</button>
				</div>



			</div>

		</div>







		<div class="row3a" style="display:none">

			<div class="row3_mian">

				<h3><i  class="iconfont">&#xe757;</i>添加单元</h3>

				<form method="post" onsubmit="return false">

					<P><span>单元名称</span></p>

					<P><input type="text" id="inname"  autocomplete="off"  value="" placeholder='请输入'/></p>

				<div id="button">

					<button type="submit" onclick="insert()">添加</button>

					<button style="display:none"></button>

					<button onclick="insertrow()">关闭</button>

				</div>

				</form>

			</div>

		</div>







		<script>





			function show(a){

				$('#showText').html(a);

				$('#showText').fadeIn();

				setTimeout(function(){ 

					$('#showText').fadeOut();

					if(a=='删除成功' ||a=='创建成功'||a=='修改成功'||a=='添加成功'){

						history.go(0);

					}

				}, 2000);	

			}	



			function go(){

				history.go(0);

			}





		</script>





		<script>	











			function godel(a){

				$.ajax({

					type:"POST",

					url:"delone",

					data:{a:a},

					success:function(c){

						if(c==1){

							show('删除成功');					

						}

					}

				})

			}





			function insertrow(){

				$('.row3a').fadeToggle();		

			}


			function xiu(a,b){
				$('#xiu').val(a);
				$('#id').val(b);
				$('.row3').fadeToggle();		
			}			
			



			function insert(){


				var inname=$('#inname').val();


				$.ajax({


				type:"POST",

				url:"insert",

				data:{inname:inname},


					success:function(c){


						if(c==1){


							show('名称不能为空');


						}else if(c==2){


							show('创建成功');			


						}


					}	


				})

			}



			function update(){
				var id=$('#id').val();
				var xiu=$('#xiu').val();
				$.ajax({
				type:"POST",
				url:"update",
				data:{id:id,xiu:xiu},
					success:function(aa){
						if(aa==1){

							show('不能为空');

						}else if(aa==2){

							show('名称已经存在');			

						}else if(aa==3){
						
							show('修改成功');
						}
					}	
				})
			}





 </script>







	</body>

</html>

