<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"/www/wwwroot/ht.mx-lucky.com/public/../application/admin/view/login/index.html";i:1550129505;}*/ ?>

<!DOCTYPE html>
<html lang="en" class="bg-dark">
<head>
    <meta charset="utf-8"/>
    <title>后台管理系统</title>
	<meta name="renderer" content="webkit" /> 
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"/>
    <link href="/static/admin/login/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/admin/login/css/animate.css" type="text/css" rel="stylesheet"/>
    <link href="/static/admin/login/css/app.css" type="text/css" rel="stylesheet"/>
	<script src="/static/admin/js/jquery.js"></script>
	<script src="https://ip.ws.126.net/ipquery"></script>
</head>
<body class="">
<section id="content" class="m-t-lg wrapper-md animated fadeInUp">
    <div class="container aside-xxl">
        <a class="navbar-brand block" href="">后台管理系统</a>
        <section class="panel panel-default bg-white m-t-lg">
            <header class="panel-heading text-center">
                <strong>管理员登陆</strong>
            </header>
            <form method="post" onsubmit="return false" class="panel-body wrapper-lg">
                <div class="form-group">
                    <label class="control-label">用户名</label>
                    <input  type="text" id="firstname" class="form-control input-lg" name="loginnum">
                </div>
                <div class="form-group">
                    <label class="control-label">密 码</label>
                    <input  type="password" id="lastname"  class="form-control input-lg" name="password">
                </div>
                <div class="form-group yzm">
                    <label class="control-label">验证码</label>
                    
					<input  type="text" id="yzm"  class="form-control input-lg" name="yzm">
					<p class="yzma" onclick="refreshVerify()"><?php echo captcha_img(); ?> </p>
                </div>

               <button type="submit" onclick="login()" class="btn btn-primary">登陆后台</button>
			   
			   <span class="register">		   
				   <a href="javascript:refreshVerify()">看不清楚？</a>
			
			   </span>
            </form>
        </section>
    </div>
</section>
<!-- footer -->
<footer id="footer">
    <div class="text-center padder">
        <p>
            <small><a href="http://wpa.qq.com/msgrd?v=3&uin=2604498096&site=qq&menu=yes"  target="_blank"/>联系客服</a> <br> </small>
        </p>
    </div>
</footer>

<div id="showText" style="display:none"></div>
<style>

#showText{position:fixed;top:35%;left:50%;z-index:999;margin-left:-75px;margin-top:-12.5px;line-height:25px;display:inline-block;background:rgba(0,0,0,.5);color:#fff;font-size:12px;width:150px;height:25px;border-radius:3px;text-align:center;}

</style>



<script accept-charset="utf-8">
	function show(a){
		$('#showText').html(a);
		$('#showText').fadeIn();
		setTimeout(function(){ 
			$('#showText').fadeOut();
			if(a=='登录成功' ){
			
				window.location="http://ht.mx-lucky.com/home";
			}else if(a=='验证码不正确'){
			
				refreshVerify();
			}
		}, 2000);	
	}

	
    function refreshVerify() {
		
       var ts = Date.parse(new Date())/1000;
	   var url=$('.yzm img').attr('src');
        $('.yzm img').attr("src", url+'?'+ts);

		
    }



	function login(){
		
		var name=$('#firstname').val();
		var pw=$('#lastname').val();
		var yzm=$('#yzm').val();	
		var add =localAddress.province+"-"+localAddress.city;

	
			$.ajax({
		
			type:"POST",
			url:"http://ht.mx-lucky.com/admin/index/comlogin",
			data:{name:name,pw:pw,yzm:yzm,add:add},

				success:function(a){

					
					if(a==1){
					
						show('账户不能为空');
					
					}else if(a==2){
					
						show('密码不能为空');

					}else if(a==3){

						show('账户名不对');
					
					}else if(a==4){
					
						show('登录成功');			

					}else if(a==5){
					
						show('密码错误');

					}else if(a==7){
					
						show('请输入验证码');

					}else if(a==6){
					
						show('验证码不正确');
						
					}
					
				}
		
		
			})
		
		


	}
</script>
<script>

        function keyEnter(){

          if (event.keyCode==13)                         

          document.getElementById("input1").click();  

        }

</script>

</body>
</html>


